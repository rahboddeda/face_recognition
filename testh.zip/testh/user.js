document.addEventListener('DOMContentLoaded', () => {
    const nameElement = document.getElementById('name');
    const emailElement = document.getElementById('email');
    const profilePicElement = document.getElementById('profile-pic');
  
    fetch('fetch-user-data.php')
      .then(response => response.json())
      .then(data => {
        nameElement.textContent = data.name;
        emailElement.textContent = data.email;
        profilePicElement.setAttribute('src', data.profile_picture);
      })
      .catch(error => console.error('Error fetching user data:', error));
  });
  
  function generateDashboard() {
    const dateStatus = document.getElementById('date-status');
  
    // Fetch the dates data dynamically from your server using AJAX or Fetch API
    // Replace the following code with your actual implementation
    const datesData = [
      {
        date: '1st January 2022',
        status: 'Marked',
        url: 'attendance1.html',
        role: 'Teacher',
        userID: '12345',
      },
      {
        date: '2nd January 2022',
        status: 'Unmarked',
        url: 'attendance2.html',
        role: 'Teacher',
        userID: '12345',
      },
      // Add more dates as needed
    ];
  
    datesData.forEach((date, index) => {
      const dateElement = document.createElement('div');
      dateElement.innerHTML = `
        <div>
          <p class="date">${date.date}</p>
          <p id="status${index}">Status: ${date.status}</p>
          <a href="${date.url}" id="statusLink${index}" class="status-link">View Details</a>
          <p class="role">${date.role}</p>
          <p class="user-id">User ID: ${date.userID}</p>
        </div>
      `;
  
      dateElement.querySelector('.date').classList.add('date-bold');
  
      dateStatus.appendChild(dateElement);
  
      // Add click event listener to each status link
      const statusLink = document.getElementById(`statusLink${index}`);
      statusLink.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = statusLink.href;
      });
    });
  }
  
  window.onload = generateDashboard;